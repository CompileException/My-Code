# Table of contents

-   [Introduction](README.md)
-   [Showcase](documentation/showcase.md)
-   [Changelog](documentation/changelog.md)
-   [FAQ](documentation/faq.md)

## Documentation

-   [Before Setup](documentation/before-setup.md)
-   [Installing Athena](documentation/installing-athena.md)
-   [Installing Athena Advanced](documentation/installing-athena-advanced.md)
-   [Configuration](documentation/configuration.md)
-   [Console](documentation/console.md)
-   [Commands](documentation/commands.md)
-   [Hotkeys](documentation/hotkeys.md)
-   [Discord Whitelist](documentation/whitelist.md)

## Basic Scripting

-   [Adding Custom Features](documentation/scripting/adding-features.md)
-   [Adding Commands](documentation/scripting/adding-commands.md)
-   [Adding Mods](documentation/scripting/adding-mods.md)
-   [Adding Items](documentation/scripting/adding-items.md)
-   [Adding Inventory Icons](documentation/scripting/adding-inventory-icons.md)
-   [Adding Custom Sounds](documentation/scripting/adding-custom-sounds.md)
-   [Adding Jobs](documentation/scripting/adding-jobs.md)
-   [Adding Athena Events](documentation/scripting/adding-athena-events.md)
-   [Adding Action Menus](documentation/scripting/adding-action-menus.md)

## External Links

-   [alt:V Official](https://altv.mp/)
-   [Athena Gumroad Product](https://gumroad.com/l/SKpPN)
-   [Athena Discord](https://discord.gg/pZvbJmKN8Y)
