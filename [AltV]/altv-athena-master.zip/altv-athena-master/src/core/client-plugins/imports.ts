import * as alt from 'alt-client';

// Specify what you are loading here.
import './example/helloWorld';
