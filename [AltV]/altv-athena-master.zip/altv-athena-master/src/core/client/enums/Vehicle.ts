export enum CLIENT_VEHICLE_EVENTS {
    TOGGLE_SEAT = 'client:Vehicle:Seat',
    TOGGLE_DOOR = 'client:Vehicle:Door',
    TOGGLE_ENGINE = 'client:Vehicle:Engine',
    TOGGLE_LOCK = 'client:Vehicle:Lock'
}
