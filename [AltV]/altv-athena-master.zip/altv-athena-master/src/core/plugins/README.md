# What is Extra?

Extra lets you extend existing functionality or write your own by importing it into the main `imports` file.

This lets you create new behavior without having it all intertwined into the main code.

This only works for server-side at the moment.
