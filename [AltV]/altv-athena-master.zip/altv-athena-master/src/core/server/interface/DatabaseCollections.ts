export enum Collections {
    Accounts = 'accounts',
    Characters = 'characters',
    Options = 'options'
}
