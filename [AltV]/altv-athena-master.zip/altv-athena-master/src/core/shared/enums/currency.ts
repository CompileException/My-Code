export enum CurrencyTypes {
    BANK = 'bank',
    CASH = 'cash'
}
