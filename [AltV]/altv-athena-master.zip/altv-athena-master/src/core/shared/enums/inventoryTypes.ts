export enum InventoryType {
    INVENTORY = 'inventory',
    EQUIPMENT = 'equipment',
    TOOLBAR = 'toolbar',
    GROUND = 'ground',
    TAB = 'tab'
}
