export interface CharacterInfo {
    gender: string;
    age: any;
}
