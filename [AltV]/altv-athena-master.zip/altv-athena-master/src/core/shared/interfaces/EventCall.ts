export interface EventCall {
    eventName: string;
    isServer: boolean;
    callAtStart?: boolean;
}
