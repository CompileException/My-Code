export interface JobTrigger {
    image: string;
    header: string;
    summary: string;
    event: string;
}
