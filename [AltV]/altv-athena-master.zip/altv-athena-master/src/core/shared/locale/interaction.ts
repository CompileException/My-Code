export enum InteractionLocale {
    //
    TOO_FAR_AWAY = 'You are too far away to interact. Move closer.',
    DOES_NOT_EXIST = 'This object does not have an interaction.'
}
