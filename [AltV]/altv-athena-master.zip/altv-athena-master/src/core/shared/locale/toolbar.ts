export enum ToolbarLocale {
    //
    DOES_NOT_EXIST = `No item is equipped in that slot.`,
    NO_WEAPON_HASH = `Weapon does not have a hash.`
}
