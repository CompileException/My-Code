---
name: Feature Request
about: Suggest an idea for this project.
title: "[FEATURE] "
labels: feature request
assignees: ''

---

### Describe the Feature
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

### Describe how it should Work
It should allow...
