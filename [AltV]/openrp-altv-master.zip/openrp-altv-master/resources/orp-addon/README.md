# This is a simple addon with some simple examples.

If you want to load it; add `orp-addon` after loading `orp` in your `server.cfg`
