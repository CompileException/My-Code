import * as alt from 'alt';

/**
 * Retrieve ORP specific data.
 * Anything that calls `emitMeta` will be retrievable here.
 */

/*
setInterval(() => {
    alt.Player.all.forEach(player => {
        const inventory = player.getMeta('inventory');
        const equipment = player.getMeta('equipment');
        const face = player.getMeta('face');
        const skills = player.getMeta('skills');
        const bank = player.getMeta('bank');
        const cash = player.getMeta('cash');
        const vehicles = player.getMeta('vehicles');

        console.log(vehicles);
        // Remember to use vehicleFunc if you want to do anything vehicle related.
        // That only ORP can do.
    });
}, 5000);
*/
