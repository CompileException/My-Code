import * as alt from 'alt';

/**
 * Calls a vehicle specific function.
 * Check: orp/server/utility/vehicle.js
 */

/*
alt.Vehicle.all.forEach(vehicle => {
    alt.emit('orp:VehicleFunc', vehicle, 'fillFuel');
});
*/
