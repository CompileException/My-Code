# Working with this HTML stuff.

### Uses:

-   Preact
-   LESS

You need to run a command to see it and refresh cache constantly on changes.

```
npm install http-server -g
http-server . -c-1
```

Visit the local host with the port; and navigate to a folder and index file.

Example:

```
http://192.168.0.128:8080/character/index.html
```
